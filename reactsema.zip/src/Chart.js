import React, {Component} from 'react';
import * as V from 'victory';
import {VictoryChart, VictoryZoomContainer, VictoryLine, VictoryBrushContainer, VictoryAxis} from 'victory';


class Chart extends React.Component {

    constructor() {
      super();
      this.state = {};
    }
  
    handleZoom(domain) {
      this.setState({selectedDomain: domain});
    }
  
    handleBrush(domain) {
      this.setState({zoomDomain: domain});
    }
  
    render() {
      return (
        <div>
            <VictoryChart width={800} height={350} scale={{x: "time"}}
              containerComponent={
                <VictoryZoomContainer responsive={false}
                  zoomDimension="x"
                  zoomDomain={this.state.zoomDomain}
                  onZoomDomainChange={this.handleZoom.bind(this)}
                />
              }
            >
              <VictoryLine
                style={{
                  data: {stroke: "tomato"}
                }}
                data={[
                    {x: new Date(2018, 1, 1,  6:55, 20, 33), y: 20},
                    {x: new Date(2018, 1, 1, 12:55, 20, 33), y: 10},
                    {x: new Date(2018, 1, 1, 14:55, 20, 33), y:  5},
                    {x: new Date(2018, 1, 1, 16:55, 20, 33), y: 15},
                    {x: new Date(2018, 1, 1, 18:55, 20, 33), y: 13},
                    {x: new Date(2018, 1, 1, 20:55, 20, 33), y: 35},
                    {x: new Date(2018, 1, 1, 22:55, 20, 33), y: 27},
                    {x: new Date(2018, 1, 1, 23:55, 20, 33), y:  7},
                    {x: new Date(2018, 1, 1, 24:55, 20, 33), y: 27},
                    {x: new Date(2018, 1, 2,  7:55, 20, 33), y: 37},
                    {x: new Date(2018, 1, 2, 12:55, 20, 33), y: 17},
                    {x: new Date(2018, 1, 2, 15:55, 20, 33), y: 21}
                ]}
              />
  
            </VictoryChart>
  
            <VictoryChart
              padding={{top: 0, left: 50, right: 50, bottom: 30}}
              width={600} height={90} scale={{x: "time"}}
              containerComponent={
                <VictoryBrushContainer responsive={false}
                  brushDimension="x"
                  brushDomain={this.state.selectedDomain}
                  onBrushDomainChange={this.handleBrush.bind(this)}
                />
              }
            >
              <VictoryAxis
                tickValues={[
                  new Date(2018, 1, 1, 1:0),
                  /* new Date(1990, 1, 1),
                  new Date(1995, 1, 1),
                  new Date(2000, 1, 1),
                  new Date(2005, 1, 1),
                  new Date(2010, 1, 1) */
                ]}
                tickFormat={(x) => new Date(x).getFullYear()}
              />
              <VictoryLine
                style={{
                  data: {stroke: "tomato"}
                }}
                data={[
                    {x: new Date(2018, 1, 1,  6:55, 20, 33), y: 20},
                    {x: new Date(2018, 1, 1, 12:55, 20, 33), y: 10},
                    {x: new Date(2018, 1, 1, 14:55, 20, 33), y:  5},
                    {x: new Date(2018, 1, 1, 16:55, 20, 33), y: 15},
                    {x: new Date(2018, 1, 1, 18:55, 20, 33), y: 13},
                    {x: new Date(2018, 1, 1, 20:55, 20, 33), y: 35},
                    {x: new Date(2018, 1, 1, 22:55, 20, 33), y: 27},
                    {x: new Date(2018, 1, 1, 23:55, 20, 33), y:  7},
                    {x: new Date(2018, 1, 1, 24:55, 20, 33), y: 27},
                    {x: new Date(2018, 1, 2,  7:55, 20, 33), y: 37},
                    {x: new Date(2018, 1, 2, 12:55, 20, 33), y: 17},
                    {x: new Date(2018, 1, 2, 15:55, 20, 33), y: 21}
                ]}
              />
            </VictoryChart>
        </div>
      );
    }
  }
/*   ReactDOM.render(<App/>, mountNode)
 */

 export default Chart;