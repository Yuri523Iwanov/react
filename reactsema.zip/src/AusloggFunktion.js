 

   export function ausloggfunktion () {
         localStorage.clear();
        console.log(alert("Sie sind jetzt ausgeloggt")) 
        
    }

  
 